```bash
nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/user1/results/192.168.111.60/scans/_quick_tcp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_quick_tcp_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/user1/results/192.168.111.60/scans/_full_tcp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_full_tcp_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/user1/results/192.168.111.60/scans/_quick_tcp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_quick_tcp_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/user1/results/192.168.111.60/scans/_full_tcp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_full_tcp_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/user1/results/192.168.111.60/scans/_top_100_udp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_top_100_udp_nmap.xml" 192.168.111.60

impacket-getArch -target 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 135 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp135/tcp_135_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp135/xml/tcp_135_rpc_nmap.xml" 192.168.111.60

impacket-rpcdump -port 135 192.168.111.60

enum4linux-ng -A -d -v 192.168.111.60 2>&1

nbtscan -rvh 192.168.111.60 2>&1

nmap -vv --reason -Pn -T4 -sV -p 139 --script="banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/user1/results/192.168.111.60/scans/tcp139/tcp_139_smb_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp139/xml/tcp_139_smb_nmap.xml" 192.168.111.60

smbclient -L //192.168.111.60 -N -I 192.168.111.60 2>&1

smbmap -H 192.168.111.60 -P 139 2>&1

nmap -vv --reason -Pn -T4 -sV -p 445 --script="banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/user1/results/192.168.111.60/scans/tcp445/tcp_445_smb_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp445/xml/tcp_445_smb_nmap.xml" 192.168.111.60

smbmap -H 192.168.111.60 -P 445 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 139 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 445 2>&1

smbmap -H 192.168.111.60 -P 139 -R 2>&1

smbmap -H 192.168.111.60 -P 445 -R 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 139 -R 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 445 -R 2>&1

smbmap -H 192.168.111.60 -P 139 -x "ipconfig /all" 2>&1

smbmap -H 192.168.111.60 -P 445 -x "ipconfig /all" 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 139 -x "ipconfig /all" 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 445 -x "ipconfig /all" 2>&1

nmap -vv --reason -Pn -T4 -sU -sV -p 137 --script="banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/user1/results/192.168.111.60/scans/udp137/udp_137_smb_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/udp137/xml/udp_137_smb_nmap.xml" 192.168.111.60

smbmap -H 192.168.111.60 -P 137 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 137 2>&1

smbmap -H 192.168.111.60 -P 137 -R 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 137 -R 2>&1

smbmap -H 192.168.111.60 -P 137 -x "ipconfig /all" 2>&1

smbmap -u null -p "" -H 192.168.111.60 -P 137 -x "ipconfig /all" 2>&1

sslscan --show-certificate --no-colour 192.168.111.60:6783 2>&1

nmap -vv --reason -Pn -T4 -sV -p 49664 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49664/tcp_49664_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49664/xml/tcp_49664_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49665 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49665/tcp_49665_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49665/xml/tcp_49665_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49666 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49666/tcp_49666_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49666/xml/tcp_49666_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49667 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49667/tcp_49667_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49667/xml/tcp_49667_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49669 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49669/tcp_49669_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49669/xml/tcp_49669_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49670 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49670/tcp_49670_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49670/xml/tcp_49670_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49686 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49686/tcp_49686_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49686/xml/tcp_49686_rpc_nmap.xml" 192.168.111.60

nmap -vv --reason -Pn -T4 -sV -p 49689 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49689/tcp_49689_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49689/xml/tcp_49689_rpc_nmap.xml" 192.168.111.60


```