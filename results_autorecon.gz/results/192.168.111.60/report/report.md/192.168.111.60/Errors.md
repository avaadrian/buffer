```
[*] Service scan get-arch (tcp/135/msrpc/get-arch) ran a command which returned a non-zero exit code (127).
[-] Command: impacket-getArch -target 192.168.111.60
[-] Error Output:
/bin/sh: line 1: impacket-getArch: command not found


[*] Service scan rpcdump (tcp/135/msrpc/rpcdump) ran a command which returned a non-zero exit code (127).
[-] Command: impacket-rpcdump -port 135 192.168.111.60
[-] Error Output:
/bin/sh: line 1: impacket-rpcdump: command not found


[*] Service scan SMBClient (tcp/139/netbios-ssn/smbclient) ran a command which returned a non-zero exit code (1).
[-] Command: smbclient -L //192.168.111.60 -N -I 192.168.111.60 2>&1
[-] Error Output:



```