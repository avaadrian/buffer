```bash
nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN "/home/user1/results/192.168.111.60/scans/_quick_tcp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_quick_tcp_nmap.xml" 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/_quick_tcp_nmap.txt](file:///home/user1/results/192.168.111.60/scans/_quick_tcp_nmap.txt):

```
# Nmap 7.93 scan initiated Sun Oct 26 17:38:35 2025 as: nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -oN /home/user1/results/192.168.111.60/scans/_quick_tcp_nmap.txt -oX /home/user1/results/192.168.111.60/scans/xml/_quick_tcp_nmap.xml 192.168.111.60
Increasing send delay for 192.168.111.60 from 0 to 5 due to 29 out of 71 dropped probes since last increase.
adjust_timeouts2: packet supposedly had rtt of -125269 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125269 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125288 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125288 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -150140 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -150140 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -250269 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -250269 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -99920 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -99920 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -100165 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -100165 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -100170 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -100170 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -124994 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -124994 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125262 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125262 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125256 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -125256 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -150113 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -150113 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -250224 microseconds.  Ignoring time.
adjust_timeouts2: packet supposedly had rtt of -250224 microseconds.  Ignoring time.
Nmap scan report for 192.168.111.60
Host is up, received arp-response (0.00019s latency).
Scanned at 2025-10-26 17:38:35 UTC for 63s
Not shown: 997 closed tcp ports (reset)
PORT    STATE SERVICE       REASON          VERSION
135/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
139/tcp open  netbios-ssn   syn-ack ttl 128 Microsoft Windows netbios-ssn
445/tcp open  microsoft-ds? syn-ack ttl 128
MAC Address: 00:50:56:89:1E:97 (VMware)
Device type: general purpose
Running (JUST GUESSING): Microsoft Windows 10|Longhorn|XP|7|2008|Vista (99%)
OS CPE: cpe:/o:microsoft:windows_10 cpe:/o:microsoft:windows cpe:/o:microsoft:windows_xp::sp3 cpe:/o:microsoft:windows_7::sp1 cpe:/o:microsoft:windows_server_2008::sp2 cpe:/o:microsoft:windows_8 cpe:/o:microsoft:windows_vista::sp1
Aggressive OS guesses: Microsoft Windows 10 1709 - 1803 (99%), Microsoft Windows 10 1709 - 1909 (98%), Microsoft Windows 10 1809 - 1909 (94%), Microsoft Windows Longhorn (93%), Microsoft Windows XP SP3 (92%), Microsoft Windows 10 1703 (91%), Microsoft Windows 7 SP1 (91%), Microsoft Windows Server 2008 SP2 (90%), Microsoft Windows 10 1607 (90%), Microsoft Windows Server 2008 R2 (90%)
No exact OS matches for host (If you know what OS is running on it, see https://nmap.org/submit/ ).
TCP/IP fingerprint:
OS:SCAN(V=7.93%E=4%D=10/26%OT=135%CT=1%CU=43915%PV=Y%DS=1%DC=D%G=Y%M=005056
OS:%TM=68FE5CDA%P=x86_64-pc-linux-gnu)SEQ(SP=101%GCD=1%ISR=101%CI=I%II=I%TS
OS:=U)OPS(O1=M5B4NW8NNS%O2=M5B4NW8NNS%O3=M5B4NW8%O4=M5B4NW8NNS%O5=M5B4NW8NN
OS:S%O6=M5B4NNS)WIN(W1=FFFF%W2=FFFF%W3=FFFF%W4=FFFF%W5=FFFF%W6=FF70)ECN(R=Y
OS:%DF=Y%T=80%W=FFFF%O=M5B4NW8NNS%CC=N%Q=)T1(R=Y%DF=Y%T=80%S=O%A=S+%F=AS%RD
OS:=0%Q=)T2(R=Y%DF=Y%T=80%W=0%S=Z%A=S%F=AR%O=%RD=0%Q=)T3(R=Y%DF=Y%T=80%W=0%
OS:S=Z%A=O%F=AR%O=%RD=0%Q=)T4(R=Y%DF=Y%T=80%W=0%S=A%A=O%F=R%O=%RD=0%Q=)T5(R
OS:=Y%DF=Y%T=80%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)T6(R=Y%DF=Y%T=80%W=0%S=A%A=O%F
OS:=R%O=%RD=0%Q=)T7(R=Y%DF=Y%T=80%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)U1(R=Y%DF=N%
OS:T=80%IPL=164%UN=0%RIPL=G%RID=G%RIPCK=G%RUCK=G%RUD=G)U1(R=N)IE(R=Y%DFI=N%
OS:T=80%CD=Z)

Network Distance: 1 hop
TCP Sequence Prediction: Difficulty=257 (Good luck!)
IP ID Sequence Generation: Busy server or unknown class
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| nbstat: NetBIOS name: DESKTOP-G3SNNUD, NetBIOS user: <unknown>, NetBIOS MAC: 005056891e97 (VMware)
| Names:
|   DESKTOP-G3SNNUD<00>  Flags: <unique><active>
|   LATTICE<00>          Flags: <group><active>
|   DESKTOP-G3SNNUD<20>  Flags: <unique><active>
| Statistics:
|   005056891e970000000000000000000000
|   0000000000000000000000000000000000
|_  0000000000000000000000000000
| smb2-time: 
|   date: 2025-10-26T17:39:27
|_  start_date: N/A
| smb2-security-mode: 
|   311: 
|_    Message signing enabled but not required
| p2p-conficker: 
|   Checking for Conficker.C or higher...
|   Check 1 (port 12162/tcp): CLEAN (Couldn't connect)
|   Check 2 (port 64816/tcp): CLEAN (Couldn't connect)
|   Check 3 (port 39721/udp): CLEAN (Failed to receive data)
|   Check 4 (port 25937/udp): CLEAN (Timeout)
|_  0/4 checks are positive: Host is CLEAN or ports are blocked
|_clock-skew: -6s

TRACEROUTE
HOP RTT     ADDRESS
1   0.19 ms 192.168.111.60

Read data files from: /usr/bin/../share/nmap
OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Oct 26 17:39:38 2025 -- 1 IP address (1 host up) scanned in 63.63 seconds

```
