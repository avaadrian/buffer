```bash
nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN "/home/user1/results/192.168.111.60/scans/_top_100_udp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_top_100_udp_nmap.xml" 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/_top_100_udp_nmap.txt](file:///home/user1/results/192.168.111.60/scans/_top_100_udp_nmap.txt):

```
# Nmap 7.93 scan initiated Sun Oct 26 17:38:35 2025 as: nmap -vv --reason -Pn -T4 -sU -A --top-ports 100 -oN /home/user1/results/192.168.111.60/scans/_top_100_udp_nmap.txt -oX /home/user1/results/192.168.111.60/scans/xml/_top_100_udp_nmap.xml 192.168.111.60
Warning: 192.168.111.60 giving up on port because retransmission cap hit (6).
Increasing send delay for 192.168.111.60 from 100 to 200 due to 11 out of 11 dropped probes since last increase.
Increasing send delay for 192.168.111.60 from 200 to 400 due to 11 out of 13 dropped probes since last increase.
Increasing send delay for 192.168.111.60 from 400 to 800 due to 11 out of 12 dropped probes since last increase.
Increasing send delay for 192.168.111.60 from 800 to 1000 due to 11 out of 23 dropped probes since last increase.
Nmap scan report for 192.168.111.60
Host is up, received arp-response (0.00018s latency).
Scanned at 2025-10-26 17:38:35 UTC for 387s
Not shown: 81 closed udp ports (port-unreach)
PORT      STATE         SERVICE        REASON               VERSION
19/udp    open|filtered chargen        no-response
67/udp    open|filtered dhcps          no-response
68/udp    open|filtered dhcpc          no-response
111/udp   open|filtered rpcbind        no-response
123/udp   open|filtered ntp            no-response
137/udp   open          netbios-ns     udp-response ttl 128 Microsoft Windows netbios-ns (workgroup: LATTICE)
| nbns-interfaces: 
|   hostname: DESKTOP-G3SNNUD
|   interfaces: 
|_    192.168.111.60
138/udp   open|filtered netbios-dgm    no-response
162/udp   open|filtered snmptrap       no-response
500/udp   open|filtered isakmp         no-response
520/udp   open|filtered route          no-response
626/udp   open|filtered serialnumberd  no-response
999/udp   open|filtered applix         no-response
1900/udp  open|filtered upnp           no-response
2049/udp  open|filtered nfs            no-response
4500/udp  open|filtered nat-t-ike      no-response
5353/udp  open|filtered zeroconf       no-response
5632/udp  open|filtered pcanywherestat no-response
49186/udp open|filtered unknown        no-response
49200/udp open|filtered unknown        no-response
MAC Address: 00:50:56:89:1E:97 (VMware)
Too many fingerprints match this host to give specific OS details
TCP/IP fingerprint:
SCAN(V=7.93%E=4%D=10/26%OT=%CT=%CU=7%PV=Y%DS=1%DC=D%G=N%M=005056%TM=68FE5E1E%P=x86_64-pc-linux-gnu)
SEQ(CI=I%II=I)
T5(R=Y%DF=Y%T=80%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)
T6(R=Y%DF=Y%T=80%W=0%S=A%A=O%F=R%O=%RD=0%Q=)
T7(R=Y%DF=Y%T=80%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)
U1(R=Y%DF=N%T=80%IPL=164%UN=0%RIPL=G%RID=G%RIPCK=G%RUCK=G%RUD=G)
IE(R=Y%DFI=N%T=80%CD=Z)

Network Distance: 1 hop
Service Info: Host: DESKTOP-G3SNNUD; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| nbstat: NetBIOS name: DESKTOP-G3SNNUD, NetBIOS user: <unknown>, NetBIOS MAC: 005056891e97 (VMware)
| Names:
|   DESKTOP-G3SNNUD<00>  Flags: <unique><active>
|   LATTICE<00>          Flags: <group><active>
|   DESKTOP-G3SNNUD<20>  Flags: <unique><active>
| Statistics:
|   005056891e970000000000000000000000
|   0000000000000000000000000000000000
|_  0000000000000000000000000000

TRACEROUTE
HOP RTT     ADDRESS
1   0.18 ms 192.168.111.60

Read data files from: /usr/bin/../share/nmap
OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Oct 26 17:45:02 2025 -- 1 IP address (1 host up) scanned in 387.64 seconds

```
