```bash
nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN "/home/user1/results/192.168.111.60/scans/_full_tcp_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/xml/_full_tcp_nmap.xml" 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/_full_tcp_nmap.txt](file:///home/user1/results/192.168.111.60/scans/_full_tcp_nmap.txt):

```
# Nmap 7.93 scan initiated Sun Oct 26 17:38:35 2025 as: nmap -vv --reason -Pn -T4 -sV -sC --version-all -A --osscan-guess -p- -oN /home/user1/results/192.168.111.60/scans/_full_tcp_nmap.txt -oX /home/user1/results/192.168.111.60/scans/xml/_full_tcp_nmap.xml 192.168.111.60
Increasing send delay for 192.168.111.60 from 0 to 5 due to 24 out of 59 dropped probes since last increase.
Nmap scan report for 192.168.111.60
Host is up, received arp-response (0.00029s latency).
Scanned at 2025-10-26 17:38:35 UTC for 700s
Not shown: 65522 closed tcp ports (reset)
PORT      STATE SERVICE       REASON          VERSION
135/tcp   open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
139/tcp   open  netbios-ssn   syn-ack ttl 128 Microsoft Windows netbios-ssn
445/tcp   open  microsoft-ds? syn-ack ttl 128
5040/tcp  open  unknown       syn-ack ttl 128
6783/tcp  open  ssl/splashtop syn-ack ttl 128 Splashtop Remote Server
| ssl-cert: Subject: 
| Issuer: 
| Public Key type: rsa
| Public Key bits: 4096
| Signature Algorithm: sha256WithRSAEncryption
| Not valid before: 2025-10-15T19:46:58
| Not valid after:  2026-10-15T19:46:58
| MD5:   7c4b3cc6242242a41f3ab1d4565ce1f6
| SHA-1: ec20ee37ee68234edc7c9fdb9796399e3a9fd14e
| -----BEGIN CERTIFICATE-----
| MIIEeTCCAmGgAwIBAgIBATANBgkqhkiG9w0BAQsFADAAMB4XDTI1MTAxNTE5NDY1
| OFoXDTI2MTAxNTE5NDY1OFowADCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
| ggIBANU526VLbOSvQ0tUJ+7CYJ3+PbRkMfZSF5c3Ys8djEAHi9XeN910eOrDanL7
| k/elg/x36JfxIi1p5aDU8BRa3zXElL9jDPchTXVIdhEEYlibKUoJpb9oL278rOi5
| 7q5jXBr32GOuWI+JjYdyQ8N/kvqQTCzBQNDNJ0vzO7SUvZO0Zjil9xCCzaF6/xQa
| 0+67xaCanTKGZxYB7qKaJXHgBztP1UWFHJVTBJrBED1X58E6nfrh1ClGD4pWaNT1
| yMOBFGDtUnSrFu/59JG1HkmUqOgsk7d3jecUs+uja5fUtIRQ3Qj7/2T8KS3sVY9x
| NnZUH9qm9HGQxguCNSPo/mPj0cjY7zCge8xYemBWzM+RjzSYWCVzs38iN9JY5dEA
| V/W+iRYzV4Hz61q/rnfJ6FOaJI5w254tcoSzHzbDQRt6q1WnrQhhl5Pg5Mc0IVod
| boJgfevwlwAouMsju7PaPrq8s4MsyJWnOwzMnYphhUeS1AfLgmcpQI3ArB9wjBlv
| 0AROXSdPWq0THPmXcJTM6RZJ1MPN/S806tMF5LqUz4za6/DV2YutLlF6SvjemcsZ
| X/n20FYnKXUWsHCn6IEURX92U9jN9anrnE3SyPIo3ynZR2biyIESPG2y6//DF4Q+
| cVHgElRpO29iW37M7tOOl9cjuYS+2LwhSZejNupUwpzd469FAgMBAAEwDQYJKoZI
| hvcNAQELBQADggIBAIgpq4/DaY8xN7y7T3IBxTcj0lNCLJU1usGmpksWtEkQRRB9
| Bk/OgpLs61EACTsL8VrGD/zOAu34jzFoy8lJBbUYSJviurWqPpw72iZv2p4CYPnQ
| HDpWKx78lVGFJlwEvS4vsjYduGAz7+zc41ZjRcIpC2404n82yezqR+uQSeqG+XPe
| X4KordqrgFgX1VSCTyWHurJuhjDTH/E1CYl8mu5X66P6eqASB5VTV/Qlw/uSlBvR
| ZoQIjEy+38n7G4lUX/iuZvBP5F6dzhlloAmlhBN8/8vsky44d65wqgZOvIdxylMM
| TqEUuJvGQjcD22W0SzBNRR6Sb3CVFSUOo35R9Wn/JemQLz/jkjY4f/lvUioTZ4Me
| ID2QoZ9ERhKS6oZUnFZGl+sTyTmf5jpFjOlQK8DtOvOqDH+63gYq9wBzUFZ2sV/E
| PyegUT7EMcc+D211dSNQmwbHqSf9PTuBIkkrEbb5+vWzX47d2C1F0gsrrfDNvBH7
| AeiSpUUlbqzjYLzCcroAsr8WQMNu3IiHiDA6DMEpkAoXJImHKrrrxkvPh+IfRGMb
| hzhpJldWqCrgF/MZJCCn3H8WIqTa5GtJDK5LKXR9xWjqWgWZRW7e2YaW8hEm9OPP
| FgUpzjgreYbFbFqOybBpa32r8Qy1/f2HH+q/p7YjKvyanTClc/7jVTuUQbT9
|_-----END CERTIFICATE-----
49664/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49665/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49666/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49667/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49669/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49670/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49686/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49689/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
MAC Address: 00:50:56:89:1E:97 (VMware)
Device type: general purpose
Running: Microsoft Windows 10
OS CPE: cpe:/o:microsoft:windows_10
OS details: Microsoft Windows 10 1709 - 1909
TCP/IP fingerprint:
OS:SCAN(V=7.93%E=4%D=10/26%OT=135%CT=1%CU=40563%PV=Y%DS=1%DC=D%G=Y%M=005056
OS:%TM=68FE5F57%P=x86_64-pc-linux-gnu)SEQ(SP=107%GCD=1%ISR=10D%TI=I%CI=I%II
OS:=I%SS=S%TS=U)OPS(O1=M5B4NW8NNS%O2=M5B4NW8NNS%O3=M5B4NW8%O4=M5B4NW8NNS%O5
OS:=M5B4NW8NNS%O6=M5B4NNS)WIN(W1=FFFF%W2=FFFF%W3=FFFF%W4=FFFF%W5=FFFF%W6=FF
OS:70)ECN(R=Y%DF=Y%T=80%W=FFFF%O=M5B4NW8NNS%CC=N%Q=)T1(R=Y%DF=Y%T=80%S=O%A=
OS:S+%F=AS%RD=0%Q=)T2(R=Y%DF=Y%T=80%W=0%S=Z%A=S%F=AR%O=%RD=0%Q=)T3(R=Y%DF=Y
OS:%T=80%W=0%S=Z%A=O%F=AR%O=%RD=0%Q=)T4(R=Y%DF=Y%T=80%W=0%S=A%A=O%F=R%O=%RD
OS:=0%Q=)T5(R=Y%DF=Y%T=80%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)T6(R=Y%DF=Y%T=80%W=0
OS:%S=A%A=O%F=R%O=%RD=0%Q=)T7(R=Y%DF=Y%T=80%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)U1
OS:(R=Y%DF=N%T=80%IPL=164%UN=0%RIPL=G%RID=G%RIPCK=G%RUCK=G%RUD=G)IE(R=Y%DFI
OS:=N%T=80%CD=Z)

Network Distance: 1 hop
TCP Sequence Prediction: Difficulty=263 (Good luck!)
IP ID Sequence Generation: Incremental
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| nbstat: NetBIOS name: DESKTOP-G3SNNUD, NetBIOS user: <unknown>, NetBIOS MAC: 005056891e97 (VMware)
| Names:
|   DESKTOP-G3SNNUD<00>  Flags: <unique><active>
|   LATTICE<00>          Flags: <group><active>
|   DESKTOP-G3SNNUD<20>  Flags: <unique><active>
| Statistics:
|   005056891e970000000000000000000000
|   0000000000000000000000000000000000
|_  0000000000000000000000000000
| p2p-conficker: 
|   Checking for Conficker.C or higher...
|   Check 1 (port 12162/tcp): CLEAN (Couldn't connect)
|   Check 2 (port 64816/tcp): CLEAN (Couldn't connect)
|   Check 3 (port 39721/udp): CLEAN (Timeout)
|   Check 4 (port 25937/udp): CLEAN (Failed to receive data)
|_  0/4 checks are positive: Host is CLEAN or ports are blocked
|_clock-skew: -5s
| smb2-time: 
|   date: 2025-10-26T17:49:58
|_  start_date: N/A
| smb2-security-mode: 
|   311: 
|_    Message signing enabled but not required

TRACEROUTE
HOP RTT     ADDRESS
1   0.29 ms 192.168.111.60

Read data files from: /usr/bin/../share/nmap
OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Oct 26 17:50:15 2025 -- 1 IP address (1 host up) scanned in 700.96 seconds

```
