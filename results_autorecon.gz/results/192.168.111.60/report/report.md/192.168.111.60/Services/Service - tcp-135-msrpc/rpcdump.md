```bash
impacket-rpcdump -port 135 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/tcp135/tcp_135_rpc_rpcdump.txt](file:///home/user1/results/192.168.111.60/scans/tcp135/tcp_135_rpc_rpcdump.txt):

```

```
