```bash
sslscan --show-certificate --no-colour 192.168.111.60:6783 2>&1
```

[/home/user1/results/192.168.111.60/scans/tcp6783/tcp_6783_sslscan.html](file:///home/user1/results/192.168.111.60/scans/tcp6783/tcp_6783_sslscan.html):

```
ERROR: Could not open a connection to host 192.168.111.60 (192.168.111.60) on port 6783 (connect: Connection refused).
ERROR: Could not open a connection to host 192.168.111.60 (192.168.111.60) on port 6783 (connect: Connection refused).
Version: 2.0.15
OpenSSL 3.0.8 7 Feb 2023

Connected to 192.168.111.60

Testing SSL server 192.168.111.60 on port 6783 using SNI name 192.168.111.60

  SSL/TLS Protocols:
SSLv2     disabled
SSLv3     disabled
TLSv1.0   disabled
TLSv1.1   disabled
TLSv1.2   enabled
TLSv1.3   disabled

  TLS Fallback SCSV:
Server supports TLS Fallback SCSV

  TLS renegotiation:
Session renegotiation not supported

  TLS Compression:
OpenSSL version does not support compression
Rebuild with zlib1g-dev package for zlib support

  Heartbleed:
TLSv1.2 not vulnerable to heartbleed

  Supported Server Cipher(s):


```
