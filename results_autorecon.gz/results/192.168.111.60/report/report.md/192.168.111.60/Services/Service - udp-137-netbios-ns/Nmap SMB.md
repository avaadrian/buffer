```bash
nmap -vv --reason -Pn -T4 -sU -sV -p 137 --script="banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/user1/results/192.168.111.60/scans/udp137/udp_137_smb_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/udp137/xml/udp_137_smb_nmap.xml" 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/udp137/udp_137_smb_nmap.txt](file:///home/user1/results/192.168.111.60/scans/udp137/udp_137_smb_nmap.txt):

```
# Nmap 7.93 scan initiated Sun Oct 26 17:45:02 2025 as: nmap -vv --reason -Pn -T4 -sU -sV -p 137 "--script=banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN /home/user1/results/192.168.111.60/scans/udp137/udp_137_smb_nmap.txt -oX /home/user1/results/192.168.111.60/scans/udp137/xml/udp_137_smb_nmap.xml 192.168.111.60
Nmap scan report for 192.168.111.60
Host is up, received arp-response (0.00046s latency).
Scanned at 2025-10-26 17:45:03 UTC for 0s

PORT    STATE SERVICE    REASON               VERSION
137/udp open  netbios-ns udp-response ttl 128 Microsoft Windows netbios-ns (workgroup: LATTICE)
MAC Address: 00:50:56:89:1E:97 (VMware)
Service Info: Host: DESKTOP-G3SNNUD; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| nbstat: NetBIOS name: DESKTOP-G3SNNUD, NetBIOS user: <unknown>, NetBIOS MAC: 005056891e97 (VMware)
| Names:
|   DESKTOP-G3SNNUD<00>  Flags: <unique><active>
|   LATTICE<00>          Flags: <group><active>
|   DESKTOP-G3SNNUD<20>  Flags: <unique><active>
| Statistics:
|   005056891e970000000000000000000000
|   0000000000000000000000000000000000
|_  0000000000000000000000000000

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Oct 26 17:45:03 2025 -- 1 IP address (1 host up) scanned in 1.01 seconds

```
