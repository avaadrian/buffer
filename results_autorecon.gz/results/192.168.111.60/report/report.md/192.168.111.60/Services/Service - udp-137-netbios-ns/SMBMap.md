```bash
smbmap -H 192.168.111.60 -P 137 2>&1
```

[/home/user1/results/192.168.111.60/scans/udp137/smbmap-share-permissions.txt](file:///home/user1/results/192.168.111.60/scans/udp137/smbmap-share-permissions.txt):

```

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
 -----------------------------------------------------------------------------
     SMBMap - Samba Share Enumerator | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
                                
[-] Working on it...

```
```bash
smbmap -u null -p "" -H 192.168.111.60 -P 137 2>&1
```

[/home/user1/results/192.168.111.60/scans/udp137/smbmap-share-permissions.txt](file:///home/user1/results/192.168.111.60/scans/udp137/smbmap-share-permissions.txt):

```

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
 -----------------------------------------------------------------------------
     SMBMap - Samba Share Enumerator | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
                                
[-] Working on it...

```
```bash
smbmap -H 192.168.111.60 -P 137 -R 2>&1
```

[/home/user1/results/192.168.111.60/scans/udp137/smbmap-list-contents.txt](file:///home/user1/results/192.168.111.60/scans/udp137/smbmap-list-contents.txt):

```

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
 -----------------------------------------------------------------------------
     SMBMap - Samba Share Enumerator | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
                                
[-] Working on it...
[\] Working on it...
[!] Authentication error on 192.168.111.60


```
```bash
smbmap -u null -p "" -H 192.168.111.60 -P 137 -R 2>&1
```

[/home/user1/results/192.168.111.60/scans/udp137/smbmap-list-contents.txt](file:///home/user1/results/192.168.111.60/scans/udp137/smbmap-list-contents.txt):

```

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
 -----------------------------------------------------------------------------
     SMBMap - Samba Share Enumerator | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
                                
[-] Working on it...
[\] Working on it...
[!] Authentication error on 192.168.111.60


```
```bash
smbmap -H 192.168.111.60 -P 137 -x "ipconfig /all" 2>&1
```

[/home/user1/results/192.168.111.60/scans/udp137/smbmap-execute-command.txt](file:///home/user1/results/192.168.111.60/scans/udp137/smbmap-execute-command.txt):

```

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
 -----------------------------------------------------------------------------
     SMBMap - Samba Share Enumerator | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
                                
[-] Working on it...
[!] Authentication error on 192.168.111.60


```
```bash
smbmap -u null -p "" -H 192.168.111.60 -P 137 -x "ipconfig /all" 2>&1
```

[/home/user1/results/192.168.111.60/scans/udp137/smbmap-execute-command.txt](file:///home/user1/results/192.168.111.60/scans/udp137/smbmap-execute-command.txt):

```

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
 -----------------------------------------------------------------------------
     SMBMap - Samba Share Enumerator | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
[\] Working on it...
[|] Working on it...
[/] Working on it...
[-] Working on it...
                                
[-] Working on it...
[!] Authentication error on 192.168.111.60


```
