```bash
nmap -vv --reason -Pn -T4 -sV -p 49666 --script="banner,msrpc-enum,rpc-grind,rpcinfo" -oN "/home/user1/results/192.168.111.60/scans/tcp49666/tcp_49666_rpc_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp49666/xml/tcp_49666_rpc_nmap.xml" 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/tcp49666/tcp_49666_rpc_nmap.txt](file:///home/user1/results/192.168.111.60/scans/tcp49666/tcp_49666_rpc_nmap.txt):

```
# Nmap 7.93 scan initiated Sun Oct 26 17:50:16 2025 as: nmap -vv --reason -Pn -T4 -sV -p 49666 --script=banner,msrpc-enum,rpc-grind,rpcinfo -oN /home/user1/results/192.168.111.60/scans/tcp49666/tcp_49666_rpc_nmap.txt -oX /home/user1/results/192.168.111.60/scans/tcp49666/xml/tcp_49666_rpc_nmap.xml 192.168.111.60
Nmap scan report for 192.168.111.60
Host is up, received arp-response (0.00039s latency).
Scanned at 2025-10-26 17:50:16 UTC for 69s

PORT      STATE SERVICE REASON          VERSION
49666/tcp open  msrpc   syn-ack ttl 128 Microsoft Windows RPC
MAC Address: 00:50:56:89:1E:97 (VMware)
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Oct 26 17:51:25 2025 -- 1 IP address (1 host up) scanned in 69.54 seconds

```
