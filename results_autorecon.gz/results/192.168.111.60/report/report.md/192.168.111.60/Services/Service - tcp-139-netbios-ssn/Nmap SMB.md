```bash
nmap -vv --reason -Pn -T4 -sV -p 139 --script="banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN "/home/user1/results/192.168.111.60/scans/tcp139/tcp_139_smb_nmap.txt" -oX "/home/user1/results/192.168.111.60/scans/tcp139/xml/tcp_139_smb_nmap.xml" 192.168.111.60
```

[/home/user1/results/192.168.111.60/scans/tcp139/tcp_139_smb_nmap.txt](file:///home/user1/results/192.168.111.60/scans/tcp139/tcp_139_smb_nmap.txt):

```
# Nmap 7.93 scan initiated Sun Oct 26 17:39:38 2025 as: nmap -vv --reason -Pn -T4 -sV -p 139 "--script=banner,(nbstat or smb* or ssl*) and not (brute or broadcast or dos or external or fuzzer)" -oN /home/user1/results/192.168.111.60/scans/tcp139/tcp_139_smb_nmap.txt -oX /home/user1/results/192.168.111.60/scans/tcp139/xml/tcp_139_smb_nmap.xml 192.168.111.60
Nmap scan report for 192.168.111.60
Host is up, received arp-response (0.00033s latency).
Scanned at 2025-10-26 17:39:39 UTC for 16s

PORT    STATE SERVICE     REASON          VERSION
139/tcp open  netbios-ssn syn-ack ttl 128 Microsoft Windows netbios-ssn
|_smb-enum-services: ERROR: Script execution failed (use -d to debug)
MAC Address: 00:50:56:89:1E:97 (VMware)
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
|_smb-print-text: false
| smb-psexec: Can't find the service file: nmap_service.exe (or nmap_service).
| Due to false positives in antivirus software, this module is no
| longer included by default. Please download it from
| https://nmap.org/psexec/nmap_service.exe
|_and place it in nselib/data/psexec/ under the Nmap DATADIR.
| nbstat: NetBIOS name: DESKTOP-G3SNNUD, NetBIOS user: <unknown>, NetBIOS MAC: 005056891e97 (VMware)
| Names:
|   DESKTOP-G3SNNUD<00>  Flags: <unique><active>
|   LATTICE<00>          Flags: <group><active>
|   DESKTOP-G3SNNUD<20>  Flags: <unique><active>
| Statistics:
|   005056891e970000000000000000000000
|   0000000000000000000000000000000000
|_  0000000000000000000000000000
| smb-mbenum: 
|_  ERROR: Failed to connect to browser service: Could not negotiate a connection:SMB: Failed to receive bytes: ERROR
| smb2-time: 
|   date: 2025-10-26T17:39:41
|_  start_date: N/A
|_smb-vuln-ms10-061: Could not negotiate a connection:SMB: Failed to receive bytes: ERROR
| smb2-security-mode: 
|   311: 
|_    Message signing enabled but not required
| smb2-capabilities: 
|   202: 
|     Distributed File System
|   210: 
|     Distributed File System
|     Leasing
|   300: 
|     Distributed File System
|     Leasing
|   302: 
|     Distributed File System
|     Leasing
|   311: 
|     Distributed File System
|_    Leasing
| smb-protocols: 
|   dialects: 
|     202
|     210
|     300
|     302
|_    311

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Oct 26 17:39:55 2025 -- 1 IP address (1 host up) scanned in 16.81 seconds

```
