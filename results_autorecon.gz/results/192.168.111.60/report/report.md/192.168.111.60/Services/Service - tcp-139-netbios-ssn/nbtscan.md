```bash
nbtscan -rvh 192.168.111.60 2>&1
```

[/home/user1/results/192.168.111.60/scans/tcp139/nbtscan.txt](file:///home/user1/results/192.168.111.60/scans/tcp139/nbtscan.txt):

```
Doing NBT name scan for addresses from 192.168.111.60


NetBIOS Name Table for Host 192.168.111.60:

Incomplete packet, 155 bytes long.
Name             Service          Type
----------------------------------------
DESKTOP-G3SNNUD  Workstation Service
LATTICE          Domain Name
DESKTOP-G3SNNUD  File Server Service

Adapter address: 00:50:56:89:1e:97
----------------------------------------


```
