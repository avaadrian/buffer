```bash
enum4linux-ng -A -d -v 192.168.111.60 2>&1
```

[/home/user1/results/192.168.111.60/scans/tcp139/enum4linux-ng.txt](file:///home/user1/results/192.168.111.60/scans/tcp139/enum4linux-ng.txt):

```
[92mENUM4LINUX - next generation (v1.3.1)[0m

 ==========================
|    Target Information    |
 ==========================
[94m[*] Target ........... 192.168.111.60[0m
[94m[*] Username ......... ''[0m
[94m[*] Random Username .. 'mjhteqlx'[0m
[94m[*] Password ......... ''[0m
[94m[*] Timeout .......... 5 second(s)[0m

 =======================================
|    Listener Scan on 192.168.111.60    |
 =======================================
[94m[*] Checking LDAP[0m
[91m[-] Could not connect to LDAP on 389/tcp: connection refused[0m
[94m[*] Checking LDAPS[0m
[91m[-] Could not connect to LDAPS on 636/tcp: connection refused[0m
[94m[*] Checking SMB[0m
[92m[+] SMB is accessible on 445/tcp[0m
[94m[*] Checking SMB over NetBIOS[0m
[92m[+] SMB over NetBIOS is accessible on 139/tcp[0m

 =============================================================
|    NetBIOS Names and Workgroup/Domain for 192.168.111.60    |
 =============================================================
[V] Trying to get NetBIOS names information, running command: nmblookup -s /tmp/tmp_7vgtij8 -A 192.168.111.60
[92m[+] Got domain/workgroup name: LATTICE[0m
[92m[+] Full NetBIOS names information:
- DESKTOP-G3SNNUD <00> -         B <ACTIVE>  Workstation Service
- LATTICE         <00> - <GROUP> B <ACTIVE>  Domain/Workgroup Name
- DESKTOP-G3SNNUD <20> -         B <ACTIVE>  File Server Service
- MAC Address = 00-50-56-89-1E-97[0m

 ===========================================
|    SMB Dialect Check on 192.168.111.60    |
 ===========================================
[94m[*] Trying on 445/tcp[0m
[92m[+] Supported dialects and settings:
Supported dialects:
  SMB 1.0: false
  SMB 2.02: true
  SMB 2.1: true
  SMB 3.0: true
  SMB 3.1.1: true
Preferred dialect: SMB 3.0
SMB1 only: false
SMB signing required: false[0m

 =============================================================
|    Domain Information via SMB session for 192.168.111.60    |
 =============================================================
[94m[*] Enumerating via unauthenticated SMB session on 445/tcp[0m
[92m[+] Found domain information via SMB
NetBIOS computer name: DESKTOP-G3SNNUD
NetBIOS domain name: LATTICE
DNS domain: lattice.top
FQDN: DESKTOP-G3SNNUD.lattice.top
Derived membership: domain member
Derived domain: LATTICE[0m

 ===========================================
|    RPC Session Check on 192.168.111.60    |
 ===========================================
[94m[*] Check for null session[0m
[V] Attempting to make session, running command: smbclient -W LATTICE -U % -s /tmp/tmp_7vgtij8 -t 5 -c help '//192.168.111.60/ipc$'
[91m[-] Could not establish null session: STATUS_ACCESS_DENIED[0m
[94m[*] Check for random user[0m
[V] Attempting to make session, running command: smbclient -W LATTICE -U mjhteqlx% -s /tmp/tmp_7vgtij8 -t 5 -c help '//192.168.111.60/ipc$'
[91m[-] Could not establish random user session: STATUS_LOGON_FAILURE[0m
[91m[-] Sessions failed, neither null nor user sessions were possible[0m

 =================================================
|    OS Information via RPC for 192.168.111.60    |
 =================================================
[94m[*] Enumerating via unauthenticated SMB session on 445/tcp[0m
[92m[+] Found OS information via SMB[0m
[94m[*] Enumerating via 'srvinfo'[0m
[91m[-] Skipping 'srvinfo' run, not possible with provided credentials[0m
[92m[+] After merging OS information we have the following result:
OS: Windows 10, Windows Server 2019, Windows Server 2016
OS version: '10.0'
OS release: '2004'
OS build: '19041'
Native OS: not supported
Native LAN manager: not supported
Platform id: null
Server type: null
Server type string: null[0m

[93m[!] Aborting remainder of tests since sessions failed, rerun with valid credentials[0m

Completed after 0.22 seconds


```
