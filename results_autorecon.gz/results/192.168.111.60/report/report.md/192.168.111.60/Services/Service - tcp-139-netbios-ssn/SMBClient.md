```bash
smbclient -L //192.168.111.60 -N -I 192.168.111.60 2>&1
```

[/home/user1/results/192.168.111.60/scans/tcp139/smbclient.txt](file:///home/user1/results/192.168.111.60/scans/tcp139/smbclient.txt):

```
Can't load /etc/samba/smb.conf - run testparm to debug it
session setup failed: NT_STATUS_ACCESS_DENIED


```
